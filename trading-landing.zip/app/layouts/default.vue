<template>
  <div class="overflow-clip">
    <common-header />

    <div class="mx-auto min-h-[60vh] max-w-[1600px]">
      <slot />
    </div>
  </div>
</template>

<script setup></script>
