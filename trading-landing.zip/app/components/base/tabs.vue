<template>
  <div class="border-dark-gray flex border-b">
    <button
      v-for="tab in tabs"
      :key="tab.value"
      class="mr-4 border-b-2 px-2 pb-1 text-20 font-semibold text-black"
      :class="
        vModel === tab.value ? 'border-trading-yellow' : 'border-transparent'
      "
      @click="vModel = tab.value"
    >
      {{ tab.title }}
    </button>

    <slot />
  </div>
</template>

<script setup>
  const vModel = defineModel({
    type: [String, Number],
    required: true,
  });

  defineProps({
    tabs: {
      type: Array,
      required: true,
    },
  });
</script>
