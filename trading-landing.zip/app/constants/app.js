export const API_CONFIG = {
  BASE_URL: "https://azapi.ok-ex.io/api/v1",
};

