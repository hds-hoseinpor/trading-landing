export const colors = {
  "trading-yellow": "#FBDD2E",
  "dark-gray": "#EBEBEB",
};
